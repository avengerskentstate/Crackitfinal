from django.apps import AppConfig


class CrackitConfig(AppConfig):
    name = 'crackit'
